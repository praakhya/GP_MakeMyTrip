#include "Headers/HotelEndpoint.hpp"
Hotel HotelEndpoint::add(Hotel accomodation){}
void HotelEndpoint::delete(Hotel accomodation){}
Hotel HotelEndpoint::modify(Hotel accomodation){}
Hotel HotelEndpoint::getByName(Hotel accomodation){}
Hotel HotelEndpoint::getByAvailability(Hotel accomodation) {}
Hotel HotelEndpoint::getByAddress(Hotel accomodation){}