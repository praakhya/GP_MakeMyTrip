class Date
{
    int day;
    int month;
    int year;

public:
    Date();
};