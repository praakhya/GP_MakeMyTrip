#include "Accomodation.hpp"
#include "AccomodationEndpoint.hpp"
#include "Hotel.hpp"

class MakeMyTrip {
    MakeMyTrip();
    void run();
};