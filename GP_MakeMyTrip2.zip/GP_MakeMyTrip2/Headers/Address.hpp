#include <string>
class Address {
    int houseNumber;
    std::string buildingName;
    std::string streetName;
    std::string cityName;
    int pinCode;
    std::string stateName;
};