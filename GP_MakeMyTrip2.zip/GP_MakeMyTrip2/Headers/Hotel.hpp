#include "Accomodation.hpp"
class Hotel : public Accomodation {

};