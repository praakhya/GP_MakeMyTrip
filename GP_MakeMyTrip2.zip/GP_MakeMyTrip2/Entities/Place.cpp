#include "Headers/Place.hpp"

Place::Place(){}
